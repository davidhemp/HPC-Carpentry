# Take several output files in the form output_[i].txt, each with one number in them
# and combine the numbers into one csv file


# the number of jobs in our job array
num_jobs = 4

# the name of the summary file to create
summary_filename = "summary_file.csv"

with open(summary_filename, 'w') as summary_file:
		# Write the headings in the summary file
		summary_file.write("job, max\n")

		for job in range(1,num_jobs+1):
			try:
				output_filename = "output_" + str(job) + ".txt"
				with open(output_filename, 'r') as output_file:
					# Get the number from the job output file
					file_max = output_file.readline()
					# Add the number to the summary file
					summary_file.write(str(job) + "," + str(file_max))
			except IOError:
				# Throw an error if we could not open the job output file
				print("Could not read file:", output_filename)

